FOR EXPERIENCED USERS!
If you want to change the weapon/knife skin, you can edit "scripts/items/items_game_cs2mod.txt" file: just edit the other skin ID 
after the "set item texture prefab" to the one you want (you can easily find the skin ID by checking "csgo_english.txt" file in "resource" folder to find the skin name and then find the skin ID in "items_game_csgo.txt" of the skin string token, it should be inside "paint_kits" section)

[29 Apr 2023]: if you want to change the stickers on weapons, you can edit "scripts/items/items_game_cs2mod.txt" file: just edit the other sticker ID after the "sticker slot X id" to the one you want (you can easily find the sticker ID by checking "csgo_english.txt" file in "resource" folder to find the sticker name and then find the sticker ID in "items_game_csgo.txt" of the sticker string token, it should be inside "sticker_kits" section)

[07 Jun 2023]: you can change the music kit ID by editing "music id" parameter in "scripts/items/items_game_cs2mod.txt"

[14 Sep 2023]: if you want to change the patches on agents, you can edit "cs2m/scripts/items/items_game_cs2mod.txt" file: just edit the other patch ID after the "sticker slot X id" (yes, valve are re-using sticker application system for agents' patches) to the one you want (you can easily find the patch ID by checking "csgo_english.txt" file in "resource" folder to find the patch name and then find the patch ID in "items_game_csgo.txt" of the patch string token, it should be inside "sticker_kits" section; make sure the patch item name starts with "patch_" and the patch ID contains "patch_material" path)

[18 Sep 2023]: if you have a patterned skin applied to CSGO weapon model and you want to set it for CS2 weapon model instead, find the skin token in "cs2m_skins/scripts/items/items_game_cs2_legacy_paints.txt" and use the new skin ID of the same pattern (new pattern should have "_cs2" suffix)
You can also adjust stickers' wear, scale and rotation via accommodating parameters for each sticker slot

[28 Sep 2023]: you can change the gloves model & glove skins by editing gloves data in "cs2m/scripts/items/items_game_cs2m_gloves.txt". To use CS2 glove skins, edit the gloves' skin ID after "set item texture prefab" the to the one you want (you can easily find the skin ID by checking "csgo_english.txt" file in "resource" folder to find the skin name and then find the skin ID in "items_game_csgo.txt" of the skin string token, it should be inside "paint_kits" section; the ID count for gloves should start from 10006)
Optional: you can add your own glove skins ".vmat"s in "cs2m_skins/gloves/paints" and add custom glove paint data in "cs2m_skins/scripts/items/items_game_cs2_gloves_paints.txt"
P.S. MAKE SURE YOU HAVE DEFAULT GLOVES EQUIPPED IN VANILLA CS2 BEFORE USING CUSTOM GLOVES IN THIS MOD !!!
P.P.S. Custom gloves data example is provided in "game/cs2m/scripts/items" folder!

[02 Dec 2023]: 
- added a search path for glove model replacements in "game/cs2m/cs2m_gloves" folder (VPK glove model replacements for CT & T side)
- you can change DEFAULT agents' voice prefix, endgame pose & patches ("agent stickers") by editing agents data in "cs2m/scripts/items/items_game_cs2m_agents.txt"; if you want to use a custom agent model, use model replacements via VPK multi-archives instead!
P.S. Patches only work on agent models that are specifically supported for such!

[07 Feb 2024]:
- fixed mod launch issues caused by newest Counter-Strike 2 game version
- removed "revert_mod" file
- added extra parameters for stickers to accommodate to newest Counter-Strike 2 stickers functionality

[26 Feb 2024]:
- added "dummy" vcompmat material for gloves, so they won't be painted if this material is used (use skin id "9000")
- added default arms world models, so they can be used to replace gloves via "cs2m/scripts/items/items_game_cs2m_gloves.txt"

[19 Mar 2024]:
- paintable default CT & T knives
- adjusted skin id "9000" instance to feature legacy weapon model usage (useful for displaying unskinned legacy weapon model)
- removed "weapons/paints/legacy" contents from "cs2m" folder
- added "items_game" data example for applying default arms that exist in-game (Bare Hands for Terrorists and Fingerless Gloves for Counter-Terrorists)
- tweaked "install_mod.bat" file

[20 Apr 2024]:
- "gameinfo.gi" is not affected anymore, "gameinfo_branchspecific.gi" is used to load the mod content instead
- new "install_mod.bat" file; added "revert_mod.bat" file to revert mod installation

=========================================================================

P.S. (for custom skin makers who want to use the custom skins on any map)
1) Create a skin using CS2 Workshop Item Editor (using CS2 Workshop Tools)
2) Go to your "CS2 Installation folder -> game -> csgo_addons -> workshop_items -> weapons -> paints -> workshop"
3) Copy your created skin into "CS2 Installation folder -> game -> cs2m_skins -> weapons -> paints -> legacy" folder
3.1) If your skin uses any other custom textures, make sure you copy them over to `cs2m_skins` folder too with respected paths (i.e. your skin uses "materials/ak47_cs2/asimov_1337.vmat", so you should copy this file to "cs2m_skins" so the path looks like this: "cs2m_skins/materials/ak47_cs2/asimov_1337.vmat")
4) Add your skin in "game/cs2m_skins/scripts/items/items_game_cs2_custom_paints.txt" (you can use the "an_gold" skin as a reference, all you need to do is to copy-paste the skin data and edit it to your values, make sure the skin ID is unique)
4.1) If your skin was designed for legacy (CS:GO) weapon model, add the following to your paint kit data:
"use_custom_model" "1"
5) Apply your skin to your desired weapon via "cs2m/scripts/items/items_game_cs2mod.txt" (by editing "set item texture prefab", "set item texture seed", "set item texture wear" values)

P.P.S. (for custom sticker makers who want to use the custom stickers for any weapon on any map)
1) Create a sticker using CS2 Workshop Item Editor (using CS2 Workshop Tools)
2) Go to your "CS2 Installation folder -> game -> csgo_addons -> workshop_items -> stickers -> workshop"
3) Copy your created sticker into "CS2 Installation folder -> game -> cs2m_skins -> stickers" folder (you can also create a sub-folder for your sticker)
3.1) If your sticker uses any other custom textures, make sure you copy them over to `cs2m_skins` folder too with respected paths
4) Add your sticker in "game/cs2m_skins/scripts/items/items_game_cs2_custom_stickers.txt" (you can use the "cs2_custom_sticker" sticker as a reference, all you need to do is to copy-paste the sticker data and edit it to your values, make sure the sticker ID is unique)
5) Apply your sticker(s) to your desired weapon via "cs2m/scripts/items/items_game_cs2mod.txt" (by editing "sticker slot X id", where X is the numeric sticker position from 0 to 4; you can also edit each sticker's wear, X and Y offset, scale & rotation via accommodating parameters)